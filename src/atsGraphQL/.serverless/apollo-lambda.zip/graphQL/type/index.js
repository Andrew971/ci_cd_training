const { gql } = require('apollo-server-lambda');

const typeDefs = gql`

  type Job {
    id: ID
    title: String
    location: String
    description: String
    status: String
    stage: String
    postings: [Posting]
  }

  type Candidate {
    id: ID
    firstname: String
    lastname: String
    occupation: String
  }

  type Applicant {
    id: ID
    jobId: ID
    candidateId: ID
    stage: String
    createdAt: String
    candidate: Candidate
  }

  type Posting {
    id: ID
    jobID: ID
    platform: String
    link: String
    postedAt: String
    details: String
  }

  type Query {
    jobs(
      searchString: String
    ): [Job]
    job(
      id: ID!,
    ): Job
    applicant(
      id: ID!,
    ): Applicant
    candidate(
      id: ID!,
    ): Candidate
  }

  input JobInput {
    title: String
    location: String
    description: String
    status: String
  }

  type Mutation {
    createJob: ID
    updateJob(
      id: ID!,
      input: JobInput
    ): Job
    deleteJob(
      id: ID!,
    ): Boolean
  }

`;


module.exports = typeDefs;
