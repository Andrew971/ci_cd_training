const low = require('lowdb');
const FileSync = require('lowdb/adapters/FileSync')
const adapter = new FileSync('./db.json');
const db = low(adapter);
const _ =require('lodash');

const job = (obj, args, context, info) => {
  
    // const res = json.jobs.find(item=>item.id===args.id)
    const res = db.get('jobs').find({id:args.id}).value();
      return  res
  
}

module.exports = job ;