const low = require('lowdb');
const FileSync = require('lowdb/adapters/FileSync')
const adapter = new FileSync('./db.json');
const db = low(adapter);
const _ =require('lodash');

const candidate = (obj, args, context, info) => {
  const test ={
    id: "c-1",
    firstname: "Joe",
    lastname: "Ridell",
    occupation: "Assistant Manager"
  };
  return test;
}

module.exports = candidate;