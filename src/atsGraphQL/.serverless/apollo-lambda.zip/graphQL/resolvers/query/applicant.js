const low = require('lowdb');
const FileSync = require('lowdb/adapters/FileSync')
const adapter = new FileSync('./db.json');
const db = low(adapter);
const _ =require('lodash');

const applicant = (obj, args, context, info) => {
  console.log('args', args);
  const applicant = db
    .get('applicants')
    .find({ id: args.id })
    .value();
  // console.log('applicant', applicant);
  // console.log({
  //   // ...applicant,
  //   candidate: db
  //     .get('candidates')
  //     .find({ id: applicant.candidateId })
  //     .value()
  // });
  return Object.assign(applicant, {
    candidate: db
      .get('candidates')
      .find({ id: applicant.candidateId })
      .value()
  })
  // return {
  //   // ...applicant,
  //   candidate: db
  //     .get('candidates')
  //     .find({ id: applicant.candidateId })
  //     .value()
  // };
}

module.exports = applicant;