const low = require('lowdb');
const FileSync = require('lowdb/adapters/FileSync')
const adapter = new FileSync('./db.json');
const db = low(adapter);
const uuidv4= require('uuid/v4');
const _ =require('lodash');

const createJob = (obj, args, context, info) => {
  const id = uuidv4(); // new ID
  db
    .get('jobs')
    .push({
      "id": id, // creating new ID here (no params came in) (later auth and createdBy etc too)
    })
    .write();
  return id;
  // return db.get('jobs').find({ id: args.id }).value();
}

module.exports = createJob;