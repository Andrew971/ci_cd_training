const low = require('lowdb');
const FileSync = require('lowdb/adapters/FileSync')
const adapter = new FileSync('./db.json');
const db = low(adapter);
const _ =require('lodash');

const deleteJob = (obj, args, context, info) => {
  return db
    .get('jobs')
    .remove({ id: args.id })
    .write();
  // use try catch blocks here! - with ApolloError etc!
}

module.exports = deleteJob;