const low = require('lowdb');
const FileSync = require('lowdb/adapters/FileSync')
const adapter = new FileSync('./db.json');
const db = low(adapter);
const _ =require('lodash');

const updateJob = (obj, args, context, info) => {
  return db
    .get('jobs')
    .find({ id: args.id })
    .assign(args.input) // validate + clean (?)
    .write();
}

module.exports = updateJob;