const {job,jobs,candidate,applicant} = require('./query')
const {createJob,updateJob,deleteJob} = require('./mutation')


const resolvers = {
  Query: {
    jobs,
    job,
    applicant,
    candidate
  },
  Mutation: {
    createJob,
    updateJob,
    deleteJob
  }
};

module.exports = resolvers;