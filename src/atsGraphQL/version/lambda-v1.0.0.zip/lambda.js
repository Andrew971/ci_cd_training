const { ApolloServer } = require('apollo-server-lambda');
const {typeDefs,resolvers} = require('./graphQL')

const server = new ApolloServer({
  typeDefs,
  resolvers
});

exports.graphqlHandler = server.createHandler();