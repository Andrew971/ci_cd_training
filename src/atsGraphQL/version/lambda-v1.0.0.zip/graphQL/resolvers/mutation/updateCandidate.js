const {dynamoDB} = require('../../config');


const updateCandidate = (obj, args, context, info) => {
    let params = {
      TableName: 'CandidateTable',
      Key: {'Id': args.Id},
      UpdateExpression: "set info = :input",
      ExpressionAttributeValues:{
        ":input":args.input,
    },
      ReturnValues:"ALL_NEW"
    }

    return dynamoDB
            .update(params)
            .promise()
            .then(data=>{
              const {Id,info} = data.Attributes;
              return Object.assign({Id}, info)
            })
            .catch(err=>console.log(err));
}

module.exports = updateCandidate;