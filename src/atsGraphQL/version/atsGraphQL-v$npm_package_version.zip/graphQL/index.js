exports.typeDefs = require('./type')
exports.resolvers = require('./resolvers')
